package com.example.ravi.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.regex.Pattern;

public class SecondActivity extends AppCompatActivity {

    private TextView result;
    private String disply = "";
    private String currentoperator = "";
    private String result1 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        result = (TextView) findViewById(R.id.textview1);
        result.setText(disply);
    }

    public void updateScreen() {
        result.setText(disply);
    }

    public void onclickNumber(View v) {
        if (result1 != "") {
            clear();
            updateScreen();
        }
        Button b = (Button) v;
        disply += b.getText();
        updateScreen();

    }

    private boolean isOperator(char op) {
        switch (op) {
            case '+':
            case '-':
            case '*':
            case '/':
                return true;
            default:
                return false;
        }
    }

    public void onclickOperator(View v) {
        if (disply == "") return;
        Button b = (Button) v;
        if (result1 != "") {
            String _disply = result1;
            result1 = "";
            disply = _disply;
        }
        if (currentoperator != "") {
            Log.d("CalcX", "" + disply.charAt(disply.length() - 1));
            if (isOperator(disply.charAt(disply.length() - 1))) {
                disply = disply.replace(disply.charAt(disply.length() - 1), b.getText().charAt(0));
                updateScreen();
                return;
            } else {
                getResult();
                disply = result1;
                result1 = "";
            }
            currentoperator = b.getText().toString();

        }

        disply += b.getText();
        currentoperator = b.getText().toString();
        updateScreen();

    }

    public void clear() {
        disply = "";
        currentoperator = "";
        result1 = "";
    }

    public void onclickClear(View v) {
        clear();
        updateScreen();
    }

    public double operate(String a, String b, String op) {
        switch (op) {
            case "+":
                return Double.valueOf(a) + Double.valueOf(b);
            case "-":
                return Double.valueOf(a) - Double.valueOf(b);
            case "*":
                return Double.valueOf(a) * Double.valueOf(b);
            case "/":
                try {
                    return Double.valueOf(a) / Double.valueOf(b);
                } catch (Exception e) {
                    Log.d("Calc", e.getMessage());
                }
            default:
                return -1;

        }
    }

    private boolean getResult() {
        if (currentoperator == "") return false;
        String[] operation = disply.split(Pattern.quote(currentoperator));
        if (operation.length < 2) return false;
        result1 = String.valueOf(operate(operation[0], operation[1], currentoperator));
        return true;
    }

    public void onclickEqual(View v) {
        if (disply == "") return;
        if (!getResult()) return;
        result.setText(disply + "\n" + String.valueOf(result1));
    }
}
