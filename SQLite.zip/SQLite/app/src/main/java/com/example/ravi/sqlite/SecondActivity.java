package com.example.ravi.sqlite;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class SecondActivity extends  AppCompatActivity{
Empdatabase empdatabase;
     ListView listView;
    SQLiteDatabase sqLiteDatabase;
    Cursor cursor;
    ListDataAdapter listDataAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        listView=(ListView)findViewById(R.id.listview1);
        listDataAdapter=new ListDataAdapter(getApplicationContext(),R.layout.row_layout);
        listView.setAdapter(listDataAdapter);
         empdatabase = new Empdatabase(getApplicationContext());
        sqLiteDatabase=empdatabase.getReadableDatabase();
        cursor=empdatabase.getinformations(sqLiteDatabase);
        if (cursor.moveToFirst()){
            do {
String id,name,mobile,address;
                id=cursor.getString(0);
                name=cursor.getString(1);
                mobile=cursor.getString(2);
                address=cursor.getString(3);
                Dataprovider dataprovider=new Dataprovider(id,name,mobile,address);
                listDataAdapter.add(dataprovider);

            }while (cursor.moveToNext());
        }

    }
}
