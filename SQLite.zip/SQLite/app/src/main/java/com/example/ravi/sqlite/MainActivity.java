package com.example.ravi.sqlite;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Empdatabase empdatabase;
    EditText edtid,edtname,edtmobile,edtaddress;
    Context context=this;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtid=(EditText)findViewById(R.id.edtId);
        edtname=(EditText)findViewById(R.id.edtName);
        edtmobile=(EditText)findViewById(R.id.edtMobile);
        edtaddress=(EditText)findViewById(R.id.edtAddress);

    }


    public void onclickSubmit(View v){
        String eid=edtid.getText().toString();
        String ename=edtname.getText().toString();
        String emobile=edtmobile.getText().toString();
        String eaddress=edtaddress.getText().toString();

        empdatabase=new Empdatabase(context);
        sqLiteDatabase = empdatabase.getWritableDatabase();
        empdatabase.addInformations(eid,ename,emobile,eaddress,sqLiteDatabase);
        Toast.makeText(getBaseContext(),"Data saved",Toast.LENGTH_SHORT).show();
        empdatabase.close();

        edtid.setText("");
        edtaddress.setText("");
        edtmobile.setText("");
        edtname.setText("");
    }
    public void onclickView(View v){
        Intent i=new Intent(MainActivity.this,SecondActivity.class);
        startActivity(i);
        finish();
    }
    public void onclickClear(View v){
        edtid.setText("");
        edtaddress.setText("");
        edtmobile.setText("");
        edtname.setText("");
    }

    public void onclickEdit(View v){
        sqLiteDatabase=empdatabase.getWritableDatabase();

        String eid=edtid.getText().toString();
        String ename=edtname.getText().toString();
        String emobile=edtmobile.getText().toString();
        String eaddress=edtaddress.getText().toString();

     empdatabase.updateInformation(eid,ename,emobile,eaddress,sqLiteDatabase);
               Toast.makeText(MainActivity.this,"Data updated",Toast.LENGTH_SHORT).show();


    }

    public void onclickDelete(View v){
        sqLiteDatabase=empdatabase.getWritableDatabase();

        String eid=edtid.getText().toString();


      empdatabase.deleteInformation(eid,sqLiteDatabase);

          Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();


        }
    }

