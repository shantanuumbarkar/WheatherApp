package com.example.ravi.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.view.View;

/**
 * Created by Ravi on 14/08/2017.
 */

public class Empdatabase extends SQLiteOpenHelper{

    private static final String DATABASE_NAME="EMPINFO.DB";
private static final int DATABASE_VERSION=1;
    private static final String CREATE_QUERY="CREATE TABLE "+Empinfo.NewEmpInfo.TABLE_NAME+"("+Empinfo.NewEmpInfo.E_ID+" TEXT,"+
            Empinfo.NewEmpInfo.E_NAME+" TEXT,"+Empinfo.NewEmpInfo.E_MOBILE+" TEXT,"+Empinfo.NewEmpInfo.E_ADDRESS+" TEXT);";

    public Empdatabase(Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        Log.e("Database operations","Database created" );
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_QUERY);
        Log.e("Database operations","table created" );

    }

    public void addInformations(String id, String name, String mobile, String address, SQLiteDatabase db){
        ContentValues contentValues = new ContentValues();
        contentValues.put(Empinfo.NewEmpInfo.E_ID,id);
        contentValues.put(Empinfo.NewEmpInfo.E_NAME,name);
        contentValues.put(Empinfo.NewEmpInfo.E_MOBILE,mobile);
        contentValues.put(Empinfo.NewEmpInfo.E_ADDRESS,address);
        db.insert(Empinfo.NewEmpInfo.TABLE_NAME,null,contentValues);
        Log.e("Database operations","one row inserted" );

    }

    public Cursor getinformations(SQLiteDatabase db){
        Cursor cursor;
        String[] projections={Empinfo.NewEmpInfo.E_ID, Empinfo.NewEmpInfo.E_NAME, Empinfo.NewEmpInfo.E_MOBILE, Empinfo.NewEmpInfo.E_ADDRESS};
        cursor=db.query(Empinfo.NewEmpInfo.TABLE_NAME,projections,null,null,null,null,null);
        return cursor;
    }

    public void updateInformation(String id, String name, String mobile, String address, SQLiteDatabase db){
        ContentValues contentValues=new ContentValues();
        contentValues.put(Empinfo.NewEmpInfo.E_ID,id);
        contentValues.put(Empinfo.NewEmpInfo.E_NAME,name);
        contentValues.put(Empinfo.NewEmpInfo.E_MOBILE,mobile);
        contentValues.put(Empinfo.NewEmpInfo.E_ADDRESS,address);
        db.update(Empinfo.NewEmpInfo.TABLE_NAME,contentValues, "E_ID=?",new String[]{String.valueOf(id)});

    }

public void deleteInformation(String id, SQLiteDatabase db){

        db.delete(Empinfo.NewEmpInfo.TABLE_NAME, "E_ID=?", new String[]{String.valueOf(id)});

}

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    }

}
