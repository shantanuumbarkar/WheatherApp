package com.example.ravi.sqlite;

/**
 * Created by Ravi on 15/08/2017.
 */

public class Empinfo {
    public static abstract class NewEmpInfo{
        public static final String TABLE_NAME="Employee_info";
        public static final String E_ID="e_id";
        public static final String E_NAME="e_name";
        public static final String E_MOBILE="e_mobile";
        public static final String E_ADDRESS="e_address";
    }
}
