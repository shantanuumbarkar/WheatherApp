package com.example.ravi.myweatherapp.data;

import org.json.JSONObject;

/**
 * Created by Ravi on 15/08/2017.
 */

public class Item implements JSONPopulator {
    private Condition condition;

    public Condition getCondition() {
        return condition;
    }

    @Override
    public void populate(JSONObject data) {
condition=new Condition();
        condition.populate(data.optJSONObject("condition"));
    }
}
