package com.example.ravi.myweatherapp.data;

import org.json.JSONObject;

/**
 * Created by Ravi on 15/08/2017.
 */

public class Units implements JSONPopulator {
    private String temperature;

    public String getTemperature() {
        return temperature;
    }

    @Override
    public void populate(JSONObject data) {
temperature=data.optString("temperature");
    }
}
