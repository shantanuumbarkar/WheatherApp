package com.example.ravi.myweatherapp.data;

import org.json.JSONObject;

/**
 * Created by Ravi on 15/08/2017.
 */

public interface JSONPopulator {
    void populate(JSONObject data);
}
