package com.example.ravi.myweatherapp.service;

import com.example.ravi.myweatherapp.data.Channel;

/**
 * Created by Ravi on 15/08/2017.
 */

public interface WeatherServiceCallback {
    void serviceSuccess(Channel channel);
    void serviceFailure(Exception exception);
}
